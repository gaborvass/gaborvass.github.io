//
//  GetSocialUIView.h
//  GetSocialUI
//
//  Created by Orest Savchak on 10/25/16.
//  Copyright © 2016 GetSocial BV. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 * @abstract Defines generic GetSocialUIView
 */
@interface GetSocialUIView : NSObject

/** @name Properties */

/*!
 *  @abstract Title of the window.
 */
@property (nonatomic, copy) NSString *windowTitle;

/** @name Methods */

/*!
 *  @abstract Shows GetSocialUIView.
 *
 *  @result YES, if view is presented without any error, otherwise NO.
 */
- (BOOL)show;

@end
