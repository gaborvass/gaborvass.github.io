//
//  GetSocialSilentExecutionPolicyDelegate.h
//  GetSocial
//
//  Created by Orest Savchak on 11/1/16.
//  Copyright © 2016 GetSocial BV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GetSocial/GetSocialExecutionPolicy.h>

@interface GetSocialSilentExecutionPolicyDelegate : NSObject<GetSocialExecutionPolicyDelegate>

@end
