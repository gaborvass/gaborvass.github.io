//
//  GetSocialPostAuthor.h
//  GetSocial
//
//  Created by Orest Savchak on 1/17/17.
//  Copyright © 2017 GetSocial BV. All rights reserved.
//

#import <GetSocial/GetSocial.h>

@interface GetSocialPostAuthor : GetSocialPublicUser

/*!
 * @abstract Verified.
 */
@property(nonatomic, readonly) BOOL verified;

@end
