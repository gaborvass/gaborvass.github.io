//
//  GetSocialCheckArgument.h
//  GetSocial
//
//  Created by Orest Savchak on 11/23/16.
//  Copyright © 2016 GetSocial BV. All rights reserved.
//

#import <Foundation/Foundation.h>

#define CheckArgumentNotNil(Argument, Name) checkNotNil(Argument, Name);
#define CheckState(State, Name) checkState(State, Name);

void checkNotNil(NSObject *object, NSString *paramName);
void checkState(BOOL state, NSString *paramName);